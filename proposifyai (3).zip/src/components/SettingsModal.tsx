import { useState, useEffect } from 'react';
import { Settings, Shield, Key, Sparkles, Check, X, Info } from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSaveSettings: (newSettings: AppSettings) => void;
}

export default function SettingsModal({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
}: SettingsModalProps) {
  const [apiMode, setApiMode] = useState<'mock' | 'live'>(settings.apiMode);
  const [showSavedToast, setShowSavedToast] = useState(false);

  useEffect(() => {
    setApiMode(settings.apiMode);
  }, [settings, isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveSettings({
      apiMode,
    });
    setShowSavedToast(true);
    setTimeout(() => {
      setShowSavedToast(false);
      onClose();
    }, 1200);
  };

  return (
    <div
      id="settings-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm transition-all animate-fade-in"
    >
      <div
        id="settings-modal-container"
        className="relative w-full max-w-md overflow-hidden rounded-2xl bg-white p-6 shadow-xl border border-slate-100 transition-all dark:bg-slate-900 dark:border-slate-800"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400">
              <Settings className="h-5 w-5 animate-spin-slow" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-50">
                Developer Settings
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Configure API endpoints and credentials
              </p>
            </div>
          </div>
          <button
            id="close-settings-btn"
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-50 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-300"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="mt-5 space-y-5">
          {/* Toggle Generation Mode */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
              Proposal Generation Engine
            </label>
            <div className="grid grid-cols-2 gap-2 rounded-xl bg-slate-50 p-1.5 dark:bg-slate-950">
              <button
                id="mode-mock-btn"
                onClick={() => setApiMode('mock')}
                className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold transition-all ${
                  apiMode === 'mock'
                    ? 'bg-white text-emerald-700 shadow-sm dark:bg-slate-800 dark:text-emerald-400'
                    : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                <Sparkles className="h-3.5 w-3.5" />
                Demo / Mock Mode
              </button>
              <button
                id="mode-live-btn"
                onClick={() => setApiMode('live')}
                className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold transition-all ${
                  apiMode === 'live'
                    ? 'bg-white text-emerald-700 shadow-sm dark:bg-slate-800 dark:text-emerald-400'
                    : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                <Key className="h-3.5 w-3.5" />
                Live API Mode
              </button>
            </div>
            <p className="text-xs text-slate-400 dark:text-slate-500">
              {apiMode === 'mock'
                ? 'Generates professional, beautiful content instantly based on preset templates (No API Key required).'
                : 'Queries real-time server-side Gemini 3.5 AI instances with actual model completion.'}
            </p>
          </div>


        </div>

        {/* Footer actions */}
        <div className="mt-6 flex gap-3 border-t border-slate-100 pt-4 dark:border-slate-800">
          <button
            id="cancel-settings-btn"
            onClick={onClose}
            className="flex-1 rounded-lg border border-slate-200 py-2 text-center text-xs font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            Cancel
          </button>
          <button
            id="save-settings-btn"
            onClick={handleSave}
            className="flex-1 flex items-center justify-center gap-1.5 rounded-lg bg-emerald-600 py-2 text-center text-xs font-semibold text-white hover:bg-emerald-700 shadow-sm"
          >
            {showSavedToast ? (
              <>
                <Check className="h-4 w-4" />
                Configuration Saved!
              </>
            ) : (
              'Save Configuration'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
