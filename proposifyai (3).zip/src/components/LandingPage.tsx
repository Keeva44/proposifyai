import { Sparkles, ArrowRight, ShieldCheck, FileSpreadsheet, FileText, Check, Layers, Users, Zap, Award, X } from 'lucide-react';

interface LandingPageProps {
  onLaunchApp: () => void;
}

export default function LandingPage({ onLaunchApp }: LandingPageProps) {
  return (
    <div id="landing-page-root" className="min-h-screen bg-slate-50 text-slate-800 font-sans tracking-normal select-none">
      {/* Navigation */}
      <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-indigo-600 shadow-md shadow-emerald-500/25">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-slate-900 to-indigo-950 bg-clip-text text-transparent">
              Proposify<span className="text-emerald-600 font-extrabold text-2xl font-mono">AI</span>
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a href="#features" className="hover:text-slate-900 transition-colors">Features</a>
            <a href="#solutions" className="hover:text-slate-900 transition-colors">Solutions</a>
            <a href="#pricing" className="hover:text-slate-900 transition-colors">Pricing</a>
          </nav>

          <button
            id="nav-launch-cta"
            onClick={onLaunchApp}
            className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700 hover:shadow transition-all"
          >
            Launch Builder
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-white py-20 pb-24 border-b border-slate-100">
        <div className="absolute inset-0 bg-[radial-gradient(#e2e8f0_1px,transparent_1px)] [background-size:16px_16px] [mask-image:radial-gradient(ellipse_50%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-60"></div>
        
        <div className="mx-auto max-w-7xl px-6 relative z-10 text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3.5 py-1 text-xs font-semibold text-emerald-800 ring-1 ring-inset ring-emerald-600/10 mb-6">
            <Sparkles className="h-3.5 w-3.5 text-emerald-600 animate-pulse" />
            Next-Gen Estimate Optimizer
          </div>
          
          <h1 className="mx-auto max-w-4xl text-5xl font-extrabold tracking-tight text-slate-950 sm:text-6xl sm:leading-[1.12]">
            Generate Win-Ready <br />
            <span className="bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">
              Proposals & Cost Estimates
            </span> in Minutes
          </h1>
          
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-slate-600">
            ProposifyAI generates professional, high-converting service estimates for residential contractors, landscapers, designers, and artisans. Complete scope drafting with real-time vector formatting.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              id="hero-launch-app-btn"
              onClick={onLaunchApp}
              className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-8 py-4 text-base font-bold text-white shadow-lg shadow-slate-900/10 hover:bg-slate-800 hover:shadow-xl transition-all"
            >
              Start Generating Free
              <ArrowRight className="h-4.5 w-4.5" />
            </button>
            <a
              href="#pricing"
              className="w-full sm:w-auto flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 px-8 py-4 text-base font-semibold text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-all bg-white"
            >
              View Pricing Tiers
            </a>
          </div>

          {/* Social proof icons */}
          <div className="mt-16 border-t border-slate-100 pt-8">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              TRUSTED BY 2,400+ TOP-TIER INDEPENDENT SERVICE FIRMS & CONTRACTORS
            </p>
            <div className="mt-4 flex flex-wrap justify-center gap-x-12 gap-y-4 text-sm font-semibold text-slate-500">
              <span className="flex items-center gap-1"><ShieldCheck className="h-4 w-4 text-emerald-600" /> Landscapers Union</span>
              <span className="flex items-center gap-1"><ShieldCheck className="h-4 w-4 text-emerald-600" /> Allied Builders Association</span>
              <span className="flex items-center gap-1"><ShieldCheck className="h-4 w-4 text-emerald-600" /> Freelance Designers Guild</span>
              <span className="flex items-center gap-1"><ShieldCheck className="h-4 w-4 text-emerald-600" /> Apex Renovations Group</span>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Grid Section */}
      <section id="features" className="py-20 bg-slate-50">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">
              Engineered Specially for Field Operators & Designers
            </h2>
            <p className="mt-4 text-base text-slate-600">
              Draft estimations, structural stages, and payment plans instantly. Say goodbye to late-night calculations and complex spreadsheets.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {/* Feature 1 */}
            <div className="relative rounded-2xl border border-slate-200 bg-white p-8 shadow-sm hover:shadow-md transition-all">
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600 mb-6">
                <FileText className="h-5.5 w-5.5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Custom B2B Copywriting</h3>
              <p className="mt-2.5 text-sm leading-relaxed text-slate-600">
                Generate high-converting, persuasive executive summaries written around your clients specific project goals, design requirements, and budget targets.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="relative rounded-2xl border border-slate-200 bg-white p-8 shadow-sm hover:shadow-md transition-all">
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 mb-6">
                <FileSpreadsheet className="h-5.5 w-5.5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Itemized Cost Estimator</h3>
              <p className="mt-2.5 text-sm leading-relaxed text-slate-600">
                Detailed breakdowns of critical raw materials, permit fees, subcontractor hourly labor tiers, and overhead buffers calculated seamlessly with proper quantities.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="relative rounded-2xl border border-slate-200 bg-white p-8 shadow-sm hover:shadow-md transition-all">
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-teal-50 text-teal-600 mb-6">
                <Layers className="h-5.5 w-5.5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Zoned Phase Timelines</h3>
              <p className="mt-2.5 text-sm leading-relaxed text-slate-600">
                Break work scopes into logical phases with distinct delivery durations to set precise, healthy boundaries and client expectations before work begins.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive split panel illustration summary banner */}
      <section id="solutions" className="py-16 bg-white border-y border-slate-100">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">Professional Grade Output</span>
              <h2 className="mt-4 text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">
                The Letterhead Layout That Wins Proposals
              </h2>
              <p className="mt-6 text-base text-slate-600 leading-relaxed">
                Standard client documentation often fails because of cluttered grids and chaotic formatting. ProposifyAI serves clean letterheads with a modern display layout, detailed tables, and clear timelines.
              </p>

              <div className="mt-8 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 rounded-full bg-emerald-50 p-1 text-emerald-600">
                    <Check className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-900">Instant PDF Blueprint Export</h4>
                    <p className="text-xs text-slate-500">Perfect physical copy downloads using dedicated digital window renderers.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 rounded-full bg-emerald-50 p-1 text-emerald-600">
                    <Check className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-900">Custom Dynamic Workspace Input</h4>
                    <p className="text-xs text-slate-500">Quickly adjust parameters for a landscaping project, interior design job, or custom remodel.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900 p-8 text-white shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-red-500"></div>
                  <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
                  <div className="h-3 w-3 rounded-full bg-green-500"></div>
                </div>
                <span className="text-xs text-slate-400 font-mono">DIGITAL_PROPOSAL_GENERATOR.json</span>
              </div>
              
              <div className="mt-6 space-y-4">
                <div className="space-y-1.5">
                  <span className="text-emerald-400 text-xs font-semibold uppercase font-mono">Executive Summary</span>
                  <p className="text-[13px] text-slate-300 leading-relaxed font-sans">
                    "We formulate this project outline with structural concrete paving pathways paired with ambient perimeter pathway LEDs for client safety..."
                  </p>
                </div>
                <div className="space-y-1.5 pt-2 border-t border-slate-800">
                  <span className="text-indigo-400 text-xs font-semibold uppercase font-mono">Materials Cost</span>
                  <div className="flex justify-between text-xs text-slate-400 font-mono">
                    <span>- Custom Pavingstone Blocks</span>
                    <span className="text-white">$5,400.00</span>
                  </div>
                  <div className="flex justify-between text-xs text-slate-400 font-mono">
                    <span>- High-Output Led System Transformer</span>
                    <span className="text-white">$540.00</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-slate-50">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">
              Pricing Options Fitted for Your Operation Scale
            </h2>
            <p className="mt-4 text-base text-slate-600">
              No long-term commitments. All templates and standard AI engines unlock on the free tier.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3 max-w-5xl mx-auto">
            {/* Starter Plan */}
            <div className="rounded-2xl border border-slate-200 bg-white p-8 text-left shadow-sm">
              <h3 className="text-base font-bold text-slate-900">Contractor Starter</h3>
              <p className="mt-2 text-xs text-slate-500">Ideal for sole freelance operators and handymen.</p>
              <div className="mt-4 flex items-baseline">
                <span className="text-4xl font-extrabold tracking-tight text-slate-900">$29</span>
                <span className="ml-1 text-xs font-semibold text-slate-500">/month</span>
              </div>
              <ul className="mt-6 space-y-3.5 text-xs text-slate-600">
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> 15 AI-Optimized Proposals/mo</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> Standard Letterhead Style</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> Vector PDF Export</li>
                <li className="flex items-center gap-2 text-slate-300"><X className="h-4 w-4" /> Multi-Agent team workspaces</li>
              </ul>
              <button
                id="pricing-starter-cta"
                onClick={onLaunchApp}
                className="mt-8 block w-full rounded-lg border border-slate-200 py-2.5 text-center text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-all cursor-pointer bg-white"
              >
                Launch Builder
              </button>
            </div>

            {/* Premium Plan (Highlighted) */}
            <div className="rounded-2xl border-2 border-emerald-500 bg-white p-8 text-left shadow-md relative">
              <div className="absolute top-0 right-6 -translate-y-1/2 rounded-full bg-emerald-500 px-3 py-0.5 text-[10px] font-bold text-white uppercase tracking-wider">
                Best Value
              </div>
              <h3 className="text-base font-bold text-slate-900">Professional Team</h3>
              <p className="mt-2 text-xs text-slate-500">For active contracting firms, landscaping crews, and studio designers.</p>
              <div className="mt-4 flex items-baseline">
                <span className="text-4xl font-extrabold tracking-tight text-slate-900">$79</span>
                <span className="ml-1 text-xs font-semibold text-slate-500">/month</span>
              </div>
              <ul className="mt-6 space-y-3.5 text-xs text-slate-600">
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> Unlimited AI Generative Proposals</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> High-Resolution Print Stylesheets</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> Custom branding & vector logo embeds</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> Custom server-side API credentialing</li>
              </ul>
              <button
                id="pricing-premium-cta"
                onClick={onLaunchApp}
                className="mt-8 block w-full rounded-lg bg-emerald-600 py-2.5 text-center text-xs font-bold text-white hover:bg-emerald-700 shadow transition-all cursor-pointer"
              >
                Launch Builder Now
              </button>
            </div>

            {/* Enterprise Plan */}
            <div className="rounded-2xl border border-slate-200 bg-white p-8 text-left shadow-sm">
              <h3 className="text-base font-bold text-slate-900">Enterprise Scale</h3>
              <p className="mt-2 text-xs text-slate-500">Best for commercial operations and national agencies.</p>
              <div className="mt-4 flex items-baseline">
                <span className="text-4xl font-extrabold tracking-tight text-slate-900">$199</span>
                <span className="ml-1 text-xs font-semibold text-slate-500">/month</span>
              </div>
              <ul className="mt-6 space-y-3.5 text-xs text-slate-600">
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> Enterprise-grade custom SLAs</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> Dedicated database & CRM hookups</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> White-glove training sessions</li>
                <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> Multiple multi-agent workspace nodes</li>
              </ul>
              <button
                id="pricing-enterprise-cta"
                onClick={onLaunchApp}
                className="mt-8 block w-full rounded-lg border border-slate-200 py-2.5 text-center text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-all cursor-pointer bg-white"
              >
                Launch Builder
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 py-12 text-slate-400 text-xs border-t border-slate-800">
        <div className="mx-auto max-w-7xl px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-1.5 text-white font-bold">
            <Sparkles className="h-4 w-4 text-emerald-400" />
            <span>ProposifyAI © 2026</span>
          </div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Safety Terms</a>
            <a href="#" className="hover:text-white transition-colors">Privacy Charter</a>
            <a href="#" className="hover:text-white transition-colors">Contact Support</a>
          </div>
          <div>
            <span>Empowered by Gemini 3.5 AI Core API</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
