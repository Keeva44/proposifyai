import { GeneratedProposal, ProjectType } from '../types';

export const MOCK_PROPOSALS: Record<ProjectType, GeneratedProposal> = {
  landscaping: {
    executiveSummary: "We are pleased to present this comprehensive landscaping and hardscape renovation proposal. Our vision is to elevate your outdoor space into a harmonious blend of sustainable beauty and practical utility. By choosing high-quality native flora coupled with durable natural flagstone pavers, we will create outdoor living zones that are not only aesthetically striking but require lower maintenance. We are committed to achieving surgical execution under high B2B standards of environmental friendliness.",
    scopeOfWork: [
      {
        task: "Site Clearing & Grading",
        description: "Clear and grub existing weed growth and poor-quality topsoil. Perform essential grading across the area to secure correct, long-term drainage redirection away from building foundations."
      },
      {
        task: "Hardscape & Stone Patio Paving",
        description: "Install high-grade polymeric sand-packed flagstone pathways and a primary dining patio area over a compressed gravel bed for structural durability against frost."
      },
      {
        task: "Softscape Installation & Irrigation Upgrade",
        description: "Plant specimen perennial species, low-wattage accent LED path lighting, and construct a zoned drip irrigation line utilizing smart timer consoles to conserve utility water."
      }
    ],
    estimatedCosts: [
      { item: "Natural Flagstone & Interlocking Pavers", quantity: 450, cost: 12 },
      { item: "Specimen Perennials & Low-water Turf Sod", quantity: 80, cost: 25 },
      { item: "Zone 1 Drip Irrigation Kit & Smart Controller", quantity: 1, cost: 750 },
      { item: "Path Light fixtures & LED transformers", quantity: 12, cost: 45 },
      { item: "Senior Skilled Hardscaper Subcontractor Labor", quantity: 48, cost: 85 }
    ],
    timeline: [
      { phase: "Phase 1: Site prep and foundational grading", duration: "2-3 Days" },
      { phase: "Phase 2: Hardscape masonry and layout paving", duration: "4-5 Days" },
      { phase: "Phase 3: Plantings, mulch spread, and lighting setup", duration: "2 Days" }
    ]
  },
  remodeling: {
    executiveSummary: "This proposal outlines the high-end interior remodeling for your residence. Our primary objective is to redesign the layout into a space maximizing thermal efficiency, natural lighting, and refined premium craftsmanship. By procuring matching grain cabinetry and quartz slab surrounds, we blend contemporary elegance with absolute resale value. The mechanical details conform strictly to modern residential codes.",
    scopeOfWork: [
      {
        task: "Surgical Demolition & Debris Disposal",
        description: "Deconstruct non-bearing drywall structures, detach outdated components, and haul all materials cleanly to a certified eco-conscious recycling depot."
      },
      {
        task: "Rough-in Electrical & Smart Lighting",
        description: "Route grade-A electrical wiring, introduce smart recessed light zones, and prepare water supply configurations behind plumbing access points."
      },
      {
        task: "Premium Cabinetry & Quartz Countertops",
        description: "Deliver and anchor solid plywood-core custom paint-grade cabinets with soft-close hardware, topped with hand-finished Calacatta quartz countertops."
      }
    ],
    estimatedCosts: [
      { item: "Premium Quartz Island Slab with Custom Edges", quantity: 1, cost: 3800 },
      { item: "Solid Plywood Paint-Grade Cabinetry Sets", quantity: 14, cost: 450 },
      { item: "LED Recessed lighting fixtures & dimmers", quantity: 18, cost: 55 },
      { item: "Pro-series Master Plumber Contracting Service", quantity: 16, cost: 120 },
      { item: "Installation Carpentry Staff Hours", quantity: 60, cost: 75 }
    ],
    timeline: [
      { phase: "Phase 1: Selective interior demolition", duration: "2 Days" },
      { phase: "Phase 2: Utilities positioning & inspection", duration: "3 Days" },
      { phase: "Phase 3: Cabinetry fitment & stone counter installation", duration: "5 Days" }
    ]
  },
  contracting: {
    executiveSummary: "ProposifyAI is proud to deliver a robust architectural construction bid package. This build strategy is optimized for structural longevity, strict load tolerance parameters, and zero safety incident tolerances. We ensure every joist, support member, and fastening point exceeds municipal structural guidelines. We provide lifetime warranty protection on foundational tie-backs.",
    scopeOfWork: [
      {
        task: "Foundational Earthwork & Sub-base Pour",
        description: "Excavate soil to required footing depths, mount reusable steel concrete forms, lay heavy rebar reinforcing mesh, and cure cement foundation."
      },
      {
        task: "Structural Framing and Sheathing",
        description: "Build load-bearing wall studs, glue-laminated ridge beams, and lay exterior OSB sheets with commercial vapor-barrier weather wraps."
      },
      {
        task: "Commercial Insulation & Drywalling",
        description: "Pack R-21 high-efficiency fiberglass batting into studs and install clean-taped moisture-resistant type-X drywall across high-traffic ceilings."
      }
    ],
    estimatedCosts: [
      { item: "Commercial-grade Ready-Mix Concrete Pour", quantity: 12, cost: 190 },
      { item: "Premium kiln-dried structural lumber (2x6 fir)", quantity: 220, cost: 8 },
      { item: "Type-X Drywall sheets with mold shielding", quantity: 45, cost: 22 },
      { item: "Heavy Duty Vapor Barrier rolls", quantity: 4, cost: 110 },
      { item: "Licensed Framing & Foundational Labor Crew", quantity: 80, cost: 95 }
    ],
    timeline: [
      { phase: "Phase 1: Concrete excavation and pouring", duration: "4 Days" },
      { phase: "Phase 2: Frame carpentry and sheathing wrap", duration: "7 Days" },
      { phase: "Phase 3: Drywall framing, tape & smooth paste work", duration: "3 Days" }
    ]
  },
  interiordesign: {
    executiveSummary: "This interior design curation matches your personal stylistic parameters with sophisticated space-planning philosophies. We seek to cultivate an ambient, cohesive color story through custom millwork finishes, premium acoustic drapery, and high-performance custom fabric palettes. The layout encourages premium organic flow and focuses on elevated ergonomics.",
    scopeOfWork: [
      {
        task: "Color Curation & Material Blueprint",
        description: "Produce high-resolution 3D color layouts and select premium paint codes alongside architectural brass plumbing trims."
      },
      {
        task: "Custom Millwork & Hardware Placement",
        description: "Anchor feature white-oak accent slatted panels on primary foyer walls and mount solid-forged brass cabinetry pulls."
      },
      {
        task: "Furnishing Layout & Lighting Curation",
        description: "Procure organic performance boucle fabric lounge chairs, premium hand-woven wool rug zones, and geometric pendant lights."
      }
    ],
    estimatedCosts: [
      { item: "White-Oak Architectural Wall Slat Panels", quantity: 8, cost: 280 },
      { item: "Solid Forged Unlacquered Brass Hardware", quantity: 32, cost: 40 },
      { item: "Geometric Hand-bent Brass Accent Pendant", quantity: 3, cost: 450 },
      { item: "Performance Boucle Ergonomic Chair Sets", quantity: 2, cost: 1100 },
      { item: "Interior Design Director Hourly Consultation", quantity: 24, cost: 150 }
    ],
    timeline: [
      { phase: "Phase 1: Color schematics and moodboards", duration: "3 Days" },
      { phase: "Phase 2: Accent millwork wall structure install", duration: "2 Days" },
      { phase: "Phase 3: Fixture anchoring and styling setup", duration: "2 Days" }
    ]
  },
  commercial: {
    executiveSummary: "This commercial contract proposal is designed to fulfill all enterprise operational specifications. Our construction and layout framework respects rigorous corporate facilities guidelines, high ADA accessibility codes, and commercial-grade durability requirements. We operate outside core business hours to prevent any impact on standard client traffic.",
    scopeOfWork: [
      {
        task: "Commercial Drywall & Soundproofing",
        description: "Erect metal-stud partition walls equipped with certified acoustic sound insulation barriers to support secure boardroom privacy."
      },
      {
        task: "Heavy-traffic Epoxy Flooring",
        description: "Grind sub-concrete slab, apply premium industrial chemical epoxy resin with safety nonslip color chips, and high-gloss topcoat."
      },
      {
        task: "Commercial HVAC Vent Upgrade",
        description: "Route high-durability spiral ducting and reposition electronic ceiling diffuse vents to standardize balanced airflow."
      }
    ],
    estimatedCosts: [
      { item: "Industrial Concrete Epoxy Base and Chips Kit", quantity: 6, cost: 350 },
      { item: "Double-thick Sound Dampening Rockwool Batt", quantity: 15, cost: 85 },
      { item: "Galvanized Spiral HVAC Duct units", quantity: 8, cost: 140 },
      { item: "Metal Structural Framing Stud packages", quantity: 40, cost: 18 },
      { item: "Licensed Commercial Engineer Consultation", quantity: 12, cost: 175 }
    ],
    timeline: [
      { phase: "Phase 1: Metal studs framing & interior lines", duration: "3 Days" },
      { phase: "Phase 2: Epoxy chemical floor laying & curing", duration: "4 Days" },
      { phase: "Phase 3: Finishes, vent mountings & final cleanup", duration: "2 Days" }
    ]
  },
  freelancedesign: {
    executiveSummary: "A personalized design and digital branding strategy created to establish your visual presence with authentic B2B sophistication. This creative plan includes holistic visual packaging, customized digital asset blueprints, and custom wireframe plans built around real target market behavior. We prioritize user experience, performance, and clean execution.",
    scopeOfWork: [
      {
        task: "Visual Brand Kit & Typographic Spec",
        description: "Establish responsive custom design guidelines, typographic scales, premium palettes, and scalable high-contrast vector components."
      },
      {
        task: "B2B Interactive Wireframing & Prototyping",
        description: "Produce elegant interactive high-fidelity design layouts outlining target marketing routes and content strategies."
      },
      {
        task: "Asset Deliverable Packaging & Export",
        description: "Export completely optimized, componentized code assets, high-res graphics, and clear visual spec guidelines."
      }
    ],
    estimatedCosts: [
      { item: "Interactive High-Fidelity UI/UX Figma Deliverables", quantity: 1, cost: 2400 },
      { item: "Vector Typography and Logo Kit Packages", quantity: 1, cost: 950 },
      { item: "Brand Guidelines Document & PDF Kit Output", quantity: 1, cost: 650 },
      { item: "Creative Director Design Consultation", quantity: 30, cost: 110 }
    ],
    timeline: [
      { phase: "Phase 1: Discover session and moodboards", duration: "4 Days" },
      { phase: "Phase 2: Concept mockups and asset layout", duration: "5 Days" },
      { phase: "Phase 3: Refinements and delivery cataloguing", duration: "3 Days" }
    ]
  }
};
