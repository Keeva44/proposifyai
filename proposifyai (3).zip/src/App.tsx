import { useState, useEffect, MouseEvent } from 'react';
import { 
  Sparkles, 
  Settings, 
  Printer, 
  ChevronRight, 
  ChevronLeft, 
  RefreshCw, 
  DollarSign, 
  Calendar, 
  MapPin, 
  Phone, 
  Mail, 
  Building2, 
  Briefcase, 
  Compass, 
  CheckCircle2, 
  Sliders, 
  Play, 
  AlertCircle,
  FileCheck2,
  Lock,
  ArrowLeft,
  Paintbrush,
  LogOut,
  UserCheck,
  CloudLightning,
  Trash2,
  Save,
  Clock,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import LandingPage from './components/LandingPage';
import SettingsModal from './components/SettingsModal';
import { FormInputs, GeneratedProposal, AppSettings, ProjectType, SavedProposal, UserProfile } from './types';
import { MOCK_PROPOSALS } from './utils/mockData';

// Firebase Integrations
import { auth, db, googleProvider, OperationType, handleFirestoreError } from './lib/firebase';
import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { collection, query, where, onSnapshot, doc, setDoc, addDoc, deleteDoc, serverTimestamp, getDoc } from 'firebase/firestore';

const PROJECT_CONTRACTORS: Record<ProjectType, { name: string; address: string; phone: string; email: string }> = {
  landscaping: {
    name: 'Luxe Scapes LLC',
    address: '122 Professional Way, Austin TX',
    phone: '(512) 555-8392',
    email: 'b2b-contracting@luxscapes.com'
  },
  remodeling: {
    name: 'Apex Renovation Studio',
    address: '409 Artisan Boulevard, Seattle WA',
    phone: '(206) 555-4081',
    email: 'ops@apexremodels.co'
  },
  contracting: {
    name: 'Standard Builders Co.',
    address: '88 Lumber Parkway, Chicago IL',
    phone: '(312) 555-0912',
    email: 'estimators@standardbuilders.com'
  },
  interiordesign: {
    name: 'Wood & Weave Design',
    address: '77 Fine Gallery Ave, New York NY',
    phone: '(212) 555-3301',
    email: 'studios@woodandweave.net'
  },
  commercial: {
    name: 'Delta Facilities & Contract',
    address: '380 Enterprise Drive, Houston TX',
    phone: '(713) 555-4422',
    email: 'b2b@deltafacilities.com'
  },
  freelancedesign: {
    name: 'PixelCraft Creative',
    address: '12 High Street, San Francisco CA',
    phone: '(415) 555-7799',
    email: 'creative@pixelcraft.io'
  }
};

const DEFAULT_INPUTS: FormInputs = {
  clientName: 'Alexander Hayes',
  projectType: 'landscaping',
  scopeOfWork: 'Installation of custom flagstone patio (800 sq ft) including integrated LED step lighting and a slate stone retaining wall for the primary garden area.',
  estimatedMaterials: 'Pennsylvania Blue Stone, High-Output LED lights, structural mortar and sand packs, polymeric sand.',
  budgetRange: '$12,000 - $18,000',
  designPreferences: 'Modern minimalist design with low utility footprint, dark slate elements, and warm accent light levels.'
};

export default function App() {
  // Page routing state
  const [isLanding, setIsLanding] = useState<boolean>(true);
  
  // Auth states
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [savedProposals, setSavedProposals] = useState<SavedProposal[]>([]);
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(true);

  // Settings state
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('proposify_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // use defaults
      }
    }
    return {
      apiMode: 'mock'
    };
  });

  const [settingsOpen, setSettingsOpen] = useState<boolean>(false);
  const [billingOpen, setBillingOpen] = useState<boolean>(false);
  const [selectedPlan, setSelectedPlan] = useState<'starter' | 'professional' | 'enterprise'>('professional');

  // Form step controls (1 to 3 progression)
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [formInputs, setFormInputs] = useState<FormInputs>(DEFAULT_INPUTS);

  // Proposal preview output
  const [proposalOutput, setProposalOutput] = useState<GeneratedProposal>(MOCK_PROPOSALS.landscaping);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  
  const [toast, setToast] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  // Sync settings helper
  const handleSaveSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    localStorage.setItem('proposify_settings', JSON.stringify(newSettings));
    showToast('success', `Switched generation to ${newSettings.apiMode === 'mock' ? 'Demo Mode' : 'Live API Mode'}`);
  };

  // Helper to trigger UI notifications
  const showToast = (type: 'success' | 'error' | 'info', message: string) => {
    setToast({ type, message });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Google Sign-In Action
  const handleSignIn = async () => {
    try {
      showToast('info', 'Connecting to Google Authentication...');
      const result = await signInWithPopup(auth, googleProvider);
      showToast('success', `Welcome back, ${result.user.displayName || 'Estimator'}!`);
    } catch (error: any) {
      console.error("Auth sign-in error", error);
      const errCode = error?.code || '';
      const errMsg = error?.message || '';
      
      if (errCode === 'auth/popup-closed-by-user' || errMsg.includes('popup-closed-by-user')) {
        showToast('info', 'The login window was closed. Please click "Google Login" again to login.');
      } else if (errCode === 'auth/popup-blocked' || errMsg.includes('popup-blocked')) {
        showToast('error', 'Login popup was blocked by your browser layout. Please enable popups for this page.');
      } else if (errCode === 'auth/unauthorized-domain' || errMsg.includes('unauthorized-domain')) {
        showToast('error', 'Unauthorized callback domain. Register this preview origin inside your Firebase project Console.');
      } else {
        showToast('error', errMsg || 'Authentication failed. Please verify configurations and retry.');
      }
    }
  };

  // Sign out Auth action
  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setUserProfile(null);
      setSavedProposals([]);
      showToast('success', 'Signed out successfully.');
    } catch (error: any) {
      showToast('error', 'Failed to log out.');
    }
  };

  // Stripe Billing session trigger
  const handleTriggerCheckout = async () => {
    try {
      showToast('info', 'Initiating secure subscription checkout...');
      
      let planName = 'Professional Team';
      let price = 79;
      
      if (selectedPlan === 'starter') {
        planName = 'Contractor Starter';
        price = 29;
      } else if (selectedPlan === 'enterprise') {
        planName = 'Enterprise Scale';
        price = 199;
      }

      const response = await fetch('/api/stripe/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: currentUser?.email || 'buyer@acquire.com',
          successUrl: `${window.location.origin}/`,
          cancelUrl: `${window.location.origin}/`,
          planName,
          price,
        }),
      });

      if (!response.ok) {
        throw new Error('Payment server rejected checkout pipeline request.');
      }

      const session = await response.json();
      showToast('success', session.simulation ? 'Simulating Stripe Checkout Sandbox...' : 'Redirecting to Stripe payment page...');
      
      // Open the URL provided (either simulated redirect url or live Stripe Session Stripe URL)
      setTimeout(() => {
        window.location.href = session.url;
      }, 1000);

    } catch (error: any) {
      console.error(error);
      showToast('error', error.message || 'Could not launch payment system.');
    }
  };

  // Listen for Authentication States
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      setIsAuthLoading(true);

      if (user) {
        // Sync user profile state in Firestore safely
        const profileRef = doc(db, 'users', user.uid);
        try {
          const docSnap = await getDoc(profileRef);
          
          if (!docSnap.exists()) {
            // Register new free tier profile automatically on first authenticated login
            const initialProfile: UserProfile = {
              uid: user.uid,
              email: user.email,
              subscriptionTier: 'free',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            
            // Create in database using rule compliance parameters
            await setDoc(profileRef, {
              uid: user.uid,
              email: user.email,
              subscriptionTier: 'free',
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            });
            setUserProfile(initialProfile);
          } else {
            const data = docSnap.data();
            setUserProfile({
              uid: data.uid,
              email: data.email,
              subscriptionTier: data.subscriptionTier || 'free',
              createdAt: data.createdAt?.toDate?.()?.toISOString() || new Date().toISOString(),
              updatedAt: data.updatedAt?.toDate?.()?.toISOString() || new Date().toISOString()
            });
          }
        } catch (error) {
          console.error("Firestore user sync error", error);
        }
      } else {
        setUserProfile(null);
      }
      setIsAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Listen for saved proposals in Firestore for the current logged-in user
  useEffect(() => {
    if (!currentUser) {
      setSavedProposals([]);
      return;
    }

    const q = query(
      collection(db, 'proposals'),
      where('ownerId', '==', currentUser.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const proposals: SavedProposal[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        proposals.push({
          id: doc.id,
          clientName: data.clientName || '',
          projectType: data.projectType || 'landscaping',
          scopeOfWork: data.scopeOfWork || '',
          estimatedMaterials: data.estimatedMaterials || '',
          budgetRange: data.budgetRange || '',
          designPreferences: data.designPreferences || '',
          executiveSummary: data.executiveSummary || '',
          scopeOfWorkOutput: JSON.parse(data.scopeOfWorkOutput || '[]'),
          estimatedCostsOutput: JSON.parse(data.estimatedCostsOutput || '[]'),
          timelineOutput: JSON.parse(data.timelineOutput || '[]'),
          ownerId: data.ownerId || '',
          createdAt: data.createdAt?.toDate?.()?.toISOString() || new Date().toISOString(),
          updatedAt: data.updatedAt?.toDate?.()?.toISOString() || new Date().toISOString()
        });
      });
      
      // Sort proposals by date descending
      proposals.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setSavedProposals(proposals);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'proposals');
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Read checkout complete tokens returned from parameter queries
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sessionId = params.get('session_id');

    if (sessionId && currentUser) {
      // Complete mock payment checkout simulation!
      const updateProfileTier = async () => {
        const profileRef = doc(db, 'users', currentUser.uid);
        try {
          await setDoc(profileRef, {
            subscriptionTier: 'premium',
            updatedAt: serverTimestamp()
          }, { merge: true });
          
          setUserProfile(prev => prev ? { ...prev, subscriptionTier: 'premium' } : null);
          showToast('success', 'License Upgraded! Premium templates unlocked successfully.');
          
          // Clear query parameters smoothly
          window.history.replaceState({}, document.title, window.location.pathname);
        } catch (error) {
          console.error("Could not complete checkout synchronize:", error);
        }
      };

      updateProfileTier();
    }
  }, [currentUser]);

  // Save Current Proposal Draft securely to cloud Firestore
  const handleSaveProposalDraft = async () => {
    if (!currentUser) {
      showToast('error', 'Please authenticate to save proposals in your cloud database.');
      return;
    }

    setIsSaving(true);
    showToast('info', 'Saving current proposal to cloud...');

    const proposalPath = 'proposals';
    try {
      // Validate inputs are full first
      const payload = {
        clientName: formInputs.clientName,
        projectType: formInputs.projectType,
        scopeOfWork: formInputs.scopeOfWork,
        estimatedMaterials: formInputs.estimatedMaterials,
        budgetRange: formInputs.budgetRange,
        designPreferences: formInputs.designPreferences,
        executiveSummary: proposalOutput.executiveSummary,
        scopeOfWorkOutput: JSON.stringify(proposalOutput.scopeOfWork),
        estimatedCostsOutput: JSON.stringify(proposalOutput.estimatedCosts),
        timelineOutput: JSON.stringify(proposalOutput.timeline),
        ownerId: currentUser.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      await addDoc(collection(db, proposalPath), payload);
      showToast('success', 'Successfully archived to secure Firestore folder!');
    } catch (error: any) {
      handleFirestoreError(error, OperationType.CREATE, proposalPath);
      showToast('error', 'Database write error. Check path rules permissions.');
    } finally {
      setIsSaving(false);
    }
  };

  // Delete matching saved proposal safely from the database collection
  const handleDeleteProposalDraft = async (id: string, event: MouseEvent) => {
    event.stopPropagation(); // prevent loading draft parameters
    
    if (!currentUser) return;
    
    showToast('info', 'Removing document from cloud indexes...');
    try {
      await deleteDoc(doc(db, 'proposals', id));
      showToast('success', 'Document permanently deleted.');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `proposals/${id}`);
      showToast('error', 'Unauthorized deletion trigger.');
    }
  };

  // Populate form and output fields on history clicks
  const handleLoadSavedProposal = (saved: SavedProposal) => {
    setFormInputs({
      clientName: saved.clientName,
      projectType: saved.projectType,
      scopeOfWork: saved.scopeOfWork,
      estimatedMaterials: saved.estimatedMaterials,
      budgetRange: saved.budgetRange,
      designPreferences: saved.designPreferences,
    });

    setProposalOutput({
      executiveSummary: saved.executiveSummary,
      scopeOfWork: saved.scopeOfWorkOutput,
      estimatedCosts: saved.estimatedCostsOutput,
      timeline: saved.timelineOutput
    });

    showToast('success', `Loaded ${saved.clientName} estimating report!`);
  };

  // Automatically update preview in mock mode when selected project type changes to keep user in delight state
  useEffect(() => {
    if (settings.apiMode === 'mock') {
      const type = formInputs.projectType;
      setProposalOutput(MOCK_PROPOSALS[type]);
    }
  }, [formInputs.projectType, settings.apiMode]);

  // Load Preset Button directly triggers form population
  const handleApplyPreset = (type: ProjectType) => {
    const presets: Record<ProjectType, FormInputs> = {
      landscaping: {
        clientName: 'Wellington Country Estate',
        projectType: 'landscaping',
        scopeOfWork: 'Construct an outdoor living oasis including a 600 sqft premium flagstone patio area, multi-zone low voltage LED boundary lighting, and native drought-resistant groundcover.',
        estimatedMaterials: 'Class-A irregular Bluestone slabs, custom LED accent brass ground stakes, landscape weed fabric, organic brown cedar mulch bags.',
        budgetRange: '$15,000 - $22,000',
        designPreferences: 'Contemporary rustic look with sustainable natural wood patterns, gray stone highlights, and soft warm white color temperatures.'
      },
      remodeling: {
        clientName: 'Dr. Evelyn Carter',
        projectType: 'remodeling',
        scopeOfWork: 'Surgical design of kitchen utility area including removal of load-bearing sheetrock walls, installation of customized matching cabinets, kitchen island, and water-supply plumbing lines.',
        estimatedMaterials: 'Calacatta Quartz heavy duty slabs, pre-assembled maple wood cabinets, energy-star built-in range unit.',
        budgetRange: '$28,000 - $35,000',
        designPreferences: 'Modern Scandinavian look with minimal visible hardware, solid white countertops, and warm matte-finished brass fixtures.'
      },
      contracting: {
        clientName: 'Horizon Multi-Family Dev',
        projectType: 'contracting',
        scopeOfWork: 'Perform professional rough-in timber framing, layout exterior wall OSB moisture sheeting, and align double-insulated composite weather barriers.',
        estimatedMaterials: 'Kiln-dried 2x6 framing studs, moisture shielding outer barrier rolls, exterior grade concrete expansion anchor bolts.',
        budgetRange: '$48,000 - $65,000',
        designPreferences: 'Heavy duty architectural spec matching municipal commercial occupancy guidelines, maximum structural energy-efficiency coefficients.'
      },
      interiordesign: {
        clientName: 'Marina Bay Penthouse',
        projectType: 'interiordesign',
        scopeOfWork: 'Full residential space styling and living room curated layout. Includes custom oak wood accent slat panels, performance boucle lounge chairs, and geometric lighting arrays.',
        estimatedMaterials: 'Select White Oak planks, custom textile upholstery fabric, custom organic wool rugs, hand-blown gallery pendant lights.',
        budgetRange: '$20,000 - $28,000',
        designPreferences: 'Ultra-refined mid-century luxury look keeping negative workspace spaces clean with quiet, elegant, bespoke accents.'
      },
      commercial: {
        clientName: 'NextGen Office Lab Solutions',
        projectType: 'commercial',
        scopeOfWork: 'Commercial office fit-out constructing deep soundproof metal-stud partitioned boardrooms, high-gloss epoxy nonslip floors, and optimized ceiling HVAC layout vents.',
        estimatedMaterials: 'Structural metal stud profiles, rockwool insulation rolls, commercial epoxy resin packages with gray aggregate mix.',
        budgetRange: '$35,000 - $45,000',
        designPreferences: 'High structural durability with maximum sound-dampening indices (STC 50+), industrial tech-grade minimal layout.'
      },
      freelancedesign: {
        clientName: 'Vanguard Biotech Inc',
        projectType: 'freelancedesign',
        scopeOfWork: 'Comprehensive digital branding package including high-fidelity interactive wireframes, custom vector component libraries, dynamic style guides, and master client presentation books.',
        estimatedMaterials: 'Digital Figma design specs, optimized SVG files asset kit, high-resolution master guidelines presentation booklet.',
        budgetRange: '$5,000 - $8,000',
        designPreferences: 'High-tech minimal look, dark modern cyber slate background with vibrant scientific green accents.'
      }
    };

    setFormInputs(presets[type]);
    showToast('info', `Applied ${type.charAt(0).toUpperCase() + type.slice(1)} preset details!`);
  };

  const handleInputChange = (field: keyof FormInputs, value: string) => {
    setFormInputs(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Live Generate Call to Express server backend wrapper
  const handleGenerateProposal = async () => {
    // Block generation if free tier and user already exhausted normal quotas (e.g. limit to 3 saved items to encourage payment!)
    if (userProfile?.subscriptionTier !== 'premium' && savedProposals.length >= 3) {
      setBillingOpen(true);
      showToast('error', 'Free limits reached. Upgrade to Premium for unlimited AI generations and cloud archives.');
      return;
    }

    setIsGenerating(true);
    showToast('info', `${settings.apiMode === 'live' ? 'Generating with Gemini AI...' : 'Loading premium mock layout...'}`);

    if (settings.apiMode === 'mock') {
      // Simulate quick natural processing delay for authentic UI premium feel
      setTimeout(() => {
        const type = formInputs.projectType;
        // Inject custom client name and budget parameters to mock details to customize it nicely
        const customMock = { ...MOCK_PROPOSALS[type] };
        customMock.executiveSummary = `We present this customized project proposal directly for ${formInputs.clientName || 'our valued client'}. ${customMock.executiveSummary} Incorporating ${formInputs.estimatedMaterials || 'high-grade professional materials'}, we fit this scope nicely inside your targeted baseline structure of ${formInputs.budgetRange || 'your estimated budget'}.`;
        
        setProposalOutput(customMock);
        setIsGenerating(false);
        showToast('success', 'Generated customized proposal instantly!');
      }, 900);
      return;
    }

    // Live API mode
    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          clientName: formInputs.clientName,
          projectType: formInputs.projectType,
          scopeOfWork: formInputs.scopeOfWork,
          estimatedMaterials: formInputs.estimatedMaterials,
          budgetRange: formInputs.budgetRange,
          designPreferences: formInputs.designPreferences,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to communicate with AI generation endpoint.');
      }

      const proposalData = await response.json();
      setProposalOutput(proposalData);
      showToast('success', 'Successfully generated fresh proposal with Gemini 3.5!');
    } catch (error: any) {
      console.error(error);
      showToast('error', error.message || 'Server Generation Error. Please check API settings.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Professional Native Printing Window Handler matching the print stylesheet rules
  const handleExportPDF = () => {
    showToast('info', 'Preparing print layout... Please verify settings in standard print dialog.');
    // Small delay to allow toaster to render
    setTimeout(() => {
      window.print();
    }, 250);
  };

  // Generate reference number based on day or name
  const getReferenceNo = () => {
    const letters = (formInputs.clientName || 'PRP').trim().toUpperCase().slice(0, 3);
    const code = Math.floor(1000 + Math.random() * 9000);
    return `#${letters}-2026-${code}`;
  };

  const calculateTotalCost = () => {
    return proposalOutput.estimatedCosts.reduce((sum, item) => sum + (item.quantity * item.cost), 0);
  };

  if (isLanding) {
    return <LandingPage onLaunchApp={() => setIsLanding(false)} />;
  }

  const contractor = PROJECT_CONTRACTORS[formInputs.projectType];

  return (
    <div className="flex flex-col min-h-screen bg-[#F8FAFC] font-sans text-slate-950 overflow-x-hidden antialiased select-none">
      
      {/* Dynamic Toast System */}
      {toast && (
        <div 
          id="toast-notification"
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 rounded-xl px-4 py-3 shadow-lg border text-sm transition-all animate-fade-in ${
            toast.type === 'success' 
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
              : toast.type === 'error' 
                ? 'bg-red-50 border-red-200 text-red-800' 
                : 'bg-indigo-50 border-indigo-200 text-indigo-800'
          }`}
        >
          {toast.type === 'success' && <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />}
          {toast.type === 'error' && <AlertCircle className="h-5 w-5 text-red-600 shrink-0" />}
          {toast.type === 'info' && <RefreshCw className="h-5 w-5 text-indigo-600 shrink-0 animate-spin" />}
          <span className="font-semibold">{toast.message}</span>
        </div>
      )}

      {/* Navigation Header */}
      <nav className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0 z-20">
        <div className="flex items-center gap-4">
          <button 
            id="back-home-btn"
            onClick={() => setIsLanding(true)}
            className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-all cursor-pointer"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Home Page
          </button>
          
          <div className="h-4 w-px bg-slate-200"></div>

          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-extrabold shadow-sm font-mono text-base">P</div>
            <span className="text-lg font-extrabold tracking-tight text-slate-900">
              Proposify<span className="text-emerald-600 font-black">AI</span>
            </span>
          </div>
        </div>

        {/* Auth status & actions bar */}
        <div className="flex items-center gap-3">
          {isAuthLoading ? (
            <div className="h-5 w-16 bg-slate-100 rounded-full animate-pulse"></div>
          ) : currentUser ? (
            <div className="flex items-center gap-2.5">
              <div className="hidden sm:flex flex-col items-end">
                <span className="text-xs font-bold text-slate-800 leading-none">{currentUser.displayName || 'Estimator'}</span>
                <span className="text-[9px] uppercase tracking-wider font-extrabold text-emerald-600 mt-0.5 flex items-center gap-0.5">
                  <CloudLightning className="h-2 w-2" />
                  {userProfile?.subscriptionTier === 'premium' ? 'Premium active' : 'Starter access'}
                </span>
              </div>
              {currentUser.photoURL ? (
                <img referrerPolicy="no-referrer" src={currentUser.photoURL} alt="Profile" className="h-7 w-7 rounded-full border border-slate-200" />
              ) : (
                <div className="h-7 w-7 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-xs">U</div>
              )}
              <button
                id="sign-out-btn"
                title="Log Out Profile"
                onClick={handleSignOut}
                className="p-1.5 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-lg border border-transparent hover:border-red-100 transition-all cursor-pointer"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              id="sign-in-btn"
              onClick={handleSignIn}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 rounded-lg text-xs font-bold text-indigo-800 transition-all cursor-pointer"
            >
              <UserCheck className="h-3.5 w-3.5" />
              Google Login
            </button>
          )}

          <div className="h-4 w-px bg-slate-200 hidden sm:block"></div>

          {/* Premium license triggers */}
          {userProfile?.subscriptionTier !== 'premium' && (
            <button
              id="badge-go-premium"
              onClick={() => setBillingOpen(true)}
              className="hidden lg:flex items-center gap-1 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-600 hover:to-yellow-700 text-white rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider shadow-sm transition-all animate-bounce"
            >
              <Sparkles className="h-3 w-3 animate-pulse" />
              Go Premium
            </button>
          )}

          <div className="flex gap-2">
            <button
              id="settings-trigger-btn"
              onClick={() => setSettingsOpen(true)}
              className="p-2 border border-slate-200 rounded-lg text-slate-500 hover:bg-slate-50 hover:text-slate-800 transition-all cursor-pointer"
              title="API & Mock Engine Config"
            >
              <Settings className="h-4.5 w-4.5" />
            </button>
            <button
              id="export-pdf-trigger-btn"
              onClick={handleExportPDF}
              className="bg-slate-950 text-white hover:bg-slate-800 px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Printer className="h-4 w-4" />
              Export PDF
            </button>
          </div>
        </div>
      </nav>

      {/* Main Workspace Container */}
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        
        {/* Left Side: Structured Input Wizard */}
        <aside className="w-full lg:w-[410px] bg-white border-b lg:border-b-0 lg:border-r border-slate-200 flex flex-col shrink-0">
          
          {/* Progress Header */}
          <div className="p-4 border-b border-slate-100 bg-slate-50/55">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Project Intake Form</span>
              <span className="text-xs font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-md">Step {currentStep} of 3</span>
            </div>
            
            {/* Horizontal step dots indicators */}
            <div className="mt-3 grid grid-cols-3 gap-2">
              <div className={`h-1.5 rounded-full transition-all ${currentStep >= 1 ? 'bg-emerald-600' : 'bg-slate-200'}`}></div>
              <div className={`h-1.5 rounded-full transition-all ${currentStep >= 2 ? 'bg-emerald-600' : 'bg-slate-200'}`}></div>
              <div className={`h-1.5 rounded-full transition-all ${currentStep >= 3 ? 'bg-emerald-600' : 'bg-slate-200'}`}></div>
            </div>
          </div>

          {/* Preset Fill Quick Selector */}
          <div className="p-3 bg-slate-50 border-b border-slate-100 text-left">
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5">Load Industry Preset Blueprint</label>
            <div className="flex flex-wrap gap-1">
              {(['landscaping', 'remodeling', 'contracting', 'interiordesign', 'commercial', 'freelancedesign'] as ProjectType[]).map((type) => (
                <button
                  key={type}
                  onClick={() => handleApplyPreset(type)}
                  className={`text-[10px] font-semibold px-2 py-1 rounded-md transition-all cursor-pointer ${
                    formInputs.projectType === type 
                      ? 'bg-slate-900 text-white' 
                      : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {type === 'interiordesign' ? 'Interior' : type === 'freelancedesign' ? 'Freelance' : type.charAt(0).toUpperCase() + type.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Dynamic Scrollable Form Viewboxes inside wizard */}
          <div className="flex-1 p-4 space-y-4 overflow-y-auto max-h-[calc(100vh-280px)] lg:max-h-none text-left">
            
            {/* Cloud Saved History Drawer Widget inside sidebar */}
            {currentUser && (
              <div className="p-3 border border-slate-200 bg-emerald-50/10 rounded-xl space-y-2 mb-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5 text-emerald-600" />
                    Cloud Archives ({savedProposals.length})
                  </span>
                  {userProfile?.subscriptionTier !== 'premium' && (
                    <span className="text-[9px] text-amber-600 font-semibold uppercase">{savedProposals.length}/3 Limit</span>
                  )}
                </div>
                
                {savedProposals.length === 0 ? (
                  <p className="text-[10px] text-slate-400">No saved estimates found in cloud database. Click "Save Draft" below to archive.</p>
                ) : (
                  <div className="max-h-24 overflow-y-auto space-y-1.5 pr-1 divide-y divide-slate-100">
                    {savedProposals.map((saved) => (
                      <div 
                        key={saved.id}
                        onClick={() => handleLoadSavedProposal(saved)}
                        className="flex items-center justify-between text-[11px] hover:bg-slate-100 p-1.5 rounded-lg transition-all cursor-pointer text-left"
                      >
                        <div className="truncate pr-2">
                          <p className="font-extrabold text-slate-800 truncate leading-relaxed">{saved.clientName}</p>
                          <p className="text-[9px] text-slate-400 truncate capitalize">{saved.projectType} • {saved.budgetRange}</p>
                        </div>
                        <button
                          onClick={(e) => handleDeleteProposalDraft(saved.id, e)}
                          title="Delete from database"
                          className="text-slate-400 hover:text-red-500 p-1 rounded transition-colors bg-transparent border-none cursor-pointer"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {currentStep === 1 && (
              <div className="space-y-4 animate-fade-in">
                <div className="border-l-2 border-emerald-500 pl-3 py-1 mb-2">
                  <h3 className="text-sm font-bold text-slate-900">Step 1: General Project Information</h3>
                  <p className="text-xs text-slate-500">Provide client name and industry category</p>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">Client Name</label>
                  <input
                    id="input-client-name"
                    type="text"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm transition-all focus:border-emerald-500 focus:bg-white focus:outline-none"
                    placeholder="e.g. Alexander Hayes"
                    value={formInputs.clientName}
                    onChange={(e) => handleInputChange('clientName', e.target.value)}
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">Project Category</label>
                  <select
                    id="input-project-type"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:border-emerald-500 focus:bg-white focus:outline-none"
                    value={formInputs.projectType}
                    onChange={(e) => handleInputChange('projectType', e.target.value as ProjectType)}
                  >
                    <option value="landscaping">Landscaping & Hardscaping</option>
                    <option value="remodeling">Interior Renovation & Remodeling</option>
                    <option value="contracting">General Framing & Contracting</option>
                    <option value="interiordesign">Interior Styling & Furniture Selection</option>
                    <option value="commercial">Commercial Space & Office Fitout</option>
                    <option value="freelancedesign">Freelance Branding & UI/UX Design</option>
                  </select>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-4 animate-fade-in">
                <div className="border-l-2 border-emerald-500 pl-3 py-1 mb-2">
                  <h3 className="text-sm font-bold text-slate-900">Step 2: Project Scope & Styling</h3>
                  <p className="text-xs text-slate-500">Provide core narratives and aesthetic requirements</p>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">Scope of Work</label>
                  <textarea
                    id="input-scope-of-work"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm h-28 focus:border-emerald-500 focus:bg-white focus:outline-none resize-none leading-relaxed"
                    placeholder="Provide a comprehensive summary..."
                    value={formInputs.scopeOfWork}
                    onChange={(e) => handleInputChange('scopeOfWork', e.target.value)}
                  />
                  <p className="text-[10px] text-slate-400">Descriptive metrics assist the AI configuration algorithm.</p>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">Design Style & Aesthetics</label>
                  <input
                    id="input-design-pref"
                    type="text"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:border-emerald-500 focus:bg-white focus:outline-none"
                    placeholder="e.g. Modern Minimalist, Slate element pairing"
                    value={formInputs.designPreferences}
                    onChange={(e) => handleInputChange('designPreferences', e.target.value)}
                  />
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-4 animate-fade-in">
                <div className="border-l-2 border-emerald-500 pl-3 py-1 mb-2">
                  <h3 className="text-sm font-bold text-slate-900">Step 3: Materials & Investment</h3>
                  <p className="text-xs text-slate-500">Set targeted items and client budget brackets</p>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">Primary Materials / Tools</label>
                  <input
                    id="input-materials"
                    type="text"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:border-emerald-500 focus:bg-white focus:outline-none"
                    placeholder="e.g. Class A Flagstone Pavers, structural mortar"
                    value={formInputs.estimatedMaterials}
                    onChange={(e) => handleInputChange('estimatedMaterials', e.target.value)}
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">Estimated Budget Range</label>
                  <input
                    id="input-budget-range"
                    type="text"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:border-emerald-500 focus:bg-white focus:outline-none"
                    placeholder="e.g. $15,000 - $22,000"
                    value={formInputs.budgetRange}
                    onChange={(e) => handleInputChange('budgetRange', e.target.value)}
                  />
                </div>

                <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 mt-4 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800">
                    <Sliders className="h-3.5 w-3.5 text-emerald-600" />
                    <span>Selected Engine Model</span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {settings.apiMode === 'live' 
                      ? 'Live Mode will query server-side Google Gemini 3.5. Ensure networking properties match.' 
                      : 'Mock Mode will process presets instantly with customized variables.'}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Form Wizard Navigation Bar & Draft Archiver */}
          <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <button
                id="wizard-back-btn"
                disabled={currentStep === 1}
                onClick={() => setCurrentStep(prev => Math.max(1, prev - 1))}
                className={`flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-semibold border transition-all ${
                  currentStep === 1 
                    ? 'border-slate-100 text-slate-300 cursor-not-allowed bg-slate-50' 
                    : 'border-slate-200 text-slate-600 bg-white hover:bg-slate-50 hover:text-slate-900 cursor-pointer'
                }`}
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </button>

              {/* Cloud Save Draft Trigger */}
              {currentUser && (
                <button
                  id="draft-save-cloud-btn"
                  onClick={handleSaveProposalDraft}
                  disabled={isSaving}
                  className="flex items-center gap-1 text-slate-700 hover:text-emerald-700 bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-200 px-3 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer"
                >
                  <Save className={`h-3.5 w-3.5 ${isSaving ? 'animate-bounce' : ''}`} />
                  Save Draft
                </button>
              )}

              {currentStep < 3 ? (
                <button
                  id="wizard-next-btn"
                  onClick={() => setCurrentStep(prev => Math.min(3, prev + 1))}
                  className="flex items-center gap-1 bg-slate-900 text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-slate-800 transition-all cursor-pointer"
                >
                  Next
                  <ChevronRight className="h-4 w-4" />
                </button>
              ) : (
                <button
                  id="wizard-generate-btn"
                  onClick={handleGenerateProposal}
                  disabled={isGenerating}
                  className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-xs font-extrabold transition-all cursor-pointer shadow-sm disabled:opacity-50"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="h-4.5 w-4.5 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Play className="h-4.5 w-4.5 fill-current" />
                      Generate AI
                    </>
                  )}
                </button>
              )}
            </div>

            {/* Quick Login notification for non-auth drafts */}
            {!currentUser && (
              <div className="flex items-center justify-between bg-indigo-50 border border-indigo-100 text-indigo-900 rounded-lg p-2 text-[10px] font-semibold text-left">
                <span>Sign in with Google to persistent save this scope to clear cloud archives.</span>
                <button onClick={handleSignIn} className="bg-indigo-600 font-bold hover:bg-indigo-700 text-white rounded px-2 py-0.5 whitespace-nowrap border-none cursor-pointer">Sign In</button>
              </div>
            )}
          </div>
        </aside>

        {/* Right Side: Continuous Design letterhead Paper Container Mockup */}
        <section className="flex-1 bg-slate-150 p-4 md:p-8 flex justify-center items-start overflow-y-auto animate-fade-in">
          
          {/* Main Paper Sheet styled matching exact requirement & letterhead */}
          <div 
            id="proposal-print-container"
            className="w-full max-w-[640px] bg-white border border-slate-200 shadow-xl rounded-sm p-6 md:p-12 min-h-[820px] flex flex-col justify-between text-left relative transition-all"
          >
            
            {/* Loading Cover for active generations */}
            {isGenerating && (
              <div className="absolute inset-0 bg-white/70 backdrop-blur-[2px] rounded-sm flex flex-col items-center justify-center z-10">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-md animate-pulse">
                  <Sparkles className="h-5.5 w-5.5 text-white animate-spin-slow" />
                </div>
                <h4 className="text-sm font-extrabold text-slate-900 mt-4 tracking-tight">AI Estimate Generator</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-[240px] text-center leading-relaxed">
                  Analyzing cost items, scheduling parameters and drafting packaging estimates...
                </p>
              </div>
            )}

            {/* Letterhead Header Section */}
            <div>
              <div className="flex flex-col sm:flex-row justify-between items-start border-b-2 border-slate-950 pb-5 mb-5">
                <div className="space-y-1 mb-4 sm:mb-0">
                  <div className="text-2xl font-black text-slate-900 uppercase tracking-tight">PROJECT PROPOSAL</div>
                  <div className="flex items-center gap-1.5 py-0.5 text-xs text-slate-500 font-mono">
                    <span className="font-bold">REF ID:</span>
                    <span>{getReferenceNo()}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-medium">DATE: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
                </div>

                {/* Dynamic Business Information Letterhead */}
                <div className="text-left sm:text-right font-sans">
                  <div className="font-extrabold text-slate-900 text-sm">{contractor.name}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{contractor.address}</div>
                  <div className="text-[11px] text-slate-500">{contractor.phone}</div>
                  <div className="text-[11px] text-slate-500">{contractor.email}</div>
                </div>
              </div>

              {/* Client and Category Intake Bar */}
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-3 rounded-lg border border-slate-100 mb-5 text-xs text-slate-700">
                <div>
                  <span className="block font-bold text-slate-400 uppercase tracking-widest text-[9px] mb-0.5">Prepared For Client</span>
                  <span className="font-bold text-slate-900 text-sm">{formInputs.clientName || 'Valued Client'}</span>
                </div>
                <div>
                  <span className="block font-bold text-slate-400 uppercase tracking-widest text-[9px] mb-0.5">Operational Target Category</span>
                  <span className="font-semibold text-slate-900 capitalize flex items-center gap-1">
                    <Briefcase className="h-3.5 w-3.5 text-emerald-600" />
                    {formInputs.projectType === 'interiordesign' ? 'Interior Styling' : formInputs.projectType === 'freelancedesign' ? 'Freelance Branding' : formInputs.projectType}
                  </span>
                </div>
              </div>

              {/* Content Sections */}
              <div className="space-y-5">
                
                {/* 1. Executive Summary */}
                <section className="space-y-1.5">
                  <div className="flex items-center gap-1.5">
                    <FileCheck2 className="h-4 w-4 text-emerald-600 shrink-0" />
                    <h3 className="text-xs font-extrabold uppercase tracking-[0.16em] text-emerald-600">Executive Summary</h3>
                  </div>
                  <p className="text-[12.5px] leading-relaxed text-slate-600 font-serif italic pl-4 border-l-2 border-slate-200">
                    {proposalOutput.executiveSummary}
                  </p>
                </section>

                {/* 2. Scope of Deliverables with checkboxes */}
                <section className="space-y-2 select-text">
                  <div className="flex items-center gap-1.5">
                    <Compass className="h-4 w-4 text-emerald-600 shrink-0" />
                    <h3 className="text-xs font-extrabold uppercase tracking-[0.16em] text-emerald-600">Scope of Deliverables</h3>
                  </div>
                  <div className="space-y-2.5 pl-4">
                    {proposalOutput.scopeOfWork.map((task, idx) => (
                      <div key={idx} className="flex gap-3">
                        <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full mt-2 shrink-0"></div>
                        <div>
                          <p className="text-xs font-bold text-slate-950">{task.task}</p>
                          <p className="text-[11px] text-slate-500 leading-relaxed mt-0.5">{task.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                {/* 3. Detailed Cost Estimates & Tables */}
                <section className="space-y-2 select-text">
                  <div className="flex items-center gap-1.5">
                    <DollarSign className="h-4 w-4 text-emerald-600 shrink-0" />
                    <h3 className="text-xs font-extrabold uppercase tracking-[0.16em] text-emerald-600">Itemized Cost Estimates</h3>
                  </div>
                  <div className="overflow-x-auto pl-4">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 text-[9.5px] font-bold uppercase tracking-wider text-slate-400">
                          <th className="py-2">Line Item Specification</th>
                          <th className="py-2 text-right">Qty</th>
                          <th className="py-2 text-right">Unit Rate</th>
                          <th className="py-2 text-right">Line Combined</th>
                        </tr>
                      </thead>
                      <tbody className="text-xs">
                        {proposalOutput.estimatedCosts.map((cost, idx) => (
                          <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50/50">
                            <td className="py-2 font-bold text-slate-800">{cost.item}</td>
                            <td className="py-2 text-right font-semibold text-slate-600">{cost.quantity}</td>
                            <td className="py-2 text-right text-slate-500">${cost.cost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                            <td className="py-2 text-right font-bold text-slate-900">${(cost.quantity * cost.cost).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="border-t border-slate-900">
                          <td colSpan={2} className="py-3 font-semibold text-slate-900 text-xs">Total Projected Investment</td>
                          <td colSpan={2} className="py-3 text-right font-black text-slate-950 text-sm">
                            ${calculateTotalCost().toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </section>

                {/* 4. Scheduling Milestones & Phase Durations */}
                <section className="space-y-2 border-t border-slate-100 pt-4">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="h-4 w-4 text-emerald-600 shrink-0" />
                    <h3 className="text-xs font-extrabold uppercase tracking-[0.16em] text-emerald-600">Duration Milestones</h3>
                  </div>
                  <div className="grid grid-cols-3 gap-2 pl-4">
                    {proposalOutput.timeline.map((phase, idx) => (
                      <div key={idx} className="bg-slate-50 p-2 rounded border border-slate-150">
                        <span className="block text-[8.5px] uppercase tracking-wider text-slate-400 font-bold">{phase.phase}</span>
                        <span className="block mt-0.5 text-[11px] font-bold text-slate-800">{phase.duration}</span>
                      </div>
                    ))}
                  </div>
                </section>

              </div>
            </div>

            {/* Letterfoot Legal / Signatures Stamp */}
            <div className="mt-8 pt-5 border-t border-slate-200/80 flex flex-col sm:flex-row justify-between items-start sm:items-end gap-3 shrink-0">
              <div className="text-[10px] text-slate-400 font-sans space-y-0.5">
                <p>Contract and Estimates generated securely with ProposifyAI Engine v3.5</p>
                <p>© 2026 {contractor.name}. All legal and design protections applied.</p>
              </div>
              
              {/* Seal Stamp design matching minimal utility theme */}
              <div className="w-24 h-9 border border-emerald-300 bg-emerald-50/20 rounded-lg flex flex-col items-center justify-center opacity-70">
                <span className="text-[7.5px] font-black uppercase tracking-widest text-emerald-700">APPROVED PLAN</span>
                <span className="text-[7.5px] font-mono text-emerald-600">{contractor.name.split(' ')[0]} OFFICERS</span>
              </div>
            </div>

          </div>
        </section>

      </main>

      {/* Subscription Checkout Modal */}
      {billingOpen && (
        <div id="billing-modal-backdrop" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 text-left animate-fade-in">
          <div id="billing-modal-card" className="w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden p-6 relative">
            <h3 className="text-lg font-black text-slate-900 flex items-center gap-1.5">
              <Sparkles className="h-5 w-5 text-amber-500 animate-pulse" />
              ProposifyAI Professional Upgrades
            </h3>
            
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Unlock unlimited AI proposal generations, unlimited cloud archives, customizable print blueprints, and self-hosted API credentials.
            </p>

            <div className="mt-5 space-y-3">
              {/* Contractor Starter */}
              <div 
                onClick={() => setSelectedPlan('starter')}
                className={`flex justify-between items-center p-3 rounded-xl border-2 transition-all cursor-pointer text-xs ${
                  selectedPlan === 'starter' 
                    ? 'border-emerald-500 bg-emerald-50/10 shadow-sm' 
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-800">Contractor Starter</span>
                    {selectedPlan === 'starter' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>}
                  </div>
                  <span className="text-[10px] text-slate-500 block">15 AI-Optimized proposals/mo</span>
                </div>
                <div className="text-right">
                  <span className="block font-black text-slate-900 text-sm">$29<span className="text-[10px] font-normal text-slate-500">/mo</span></span>
                  <span className="text-[9px] font-bold text-slate-500">Standard tier</span>
                </div>
              </div>

              {/* Professional Team */}
              <div 
                onClick={() => setSelectedPlan('professional')}
                className={`flex justify-between items-center p-3 rounded-xl border-2 transition-all cursor-pointer text-xs relative ${
                  selectedPlan === 'professional' 
                    ? 'border-emerald-500 bg-emerald-50/10 shadow-sm' 
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="absolute -top-2 right-4 rounded-full bg-emerald-500 px-2 py-0.5 text-[8px] font-bold text-white uppercase tracking-wider">
                  Best Value
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-800">Professional Team</span>
                    {selectedPlan === 'professional' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>}
                  </div>
                  <span className="text-[10px] text-slate-500 block">Unlimited AI, custom branding</span>
                </div>
                <div className="text-right">
                  <span className="block font-black text-slate-900 text-sm">$79<span className="text-[10px] font-normal text-slate-500">/mo</span></span>
                  <span className="text-[9px] font-bold text-emerald-600">Recommended</span>
                </div>
              </div>

              {/* Enterprise Scale */}
              <div 
                onClick={() => setSelectedPlan('enterprise')}
                className={`flex justify-between items-center p-3 rounded-xl border-2 transition-all cursor-pointer text-xs ${
                  selectedPlan === 'enterprise' 
                    ? 'border-emerald-500 bg-emerald-50/10 shadow-sm' 
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-800">Enterprise Scale</span>
                    {selectedPlan === 'enterprise' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>}
                  </div>
                  <span className="text-[10px] text-slate-500 block">Dedicated DB & custom SLAs</span>
                </div>
                <div className="text-right">
                  <span className="block font-black text-slate-900 text-sm">$199<span className="text-[10px] font-normal text-slate-500">/mo</span></span>
                  <span className="text-[9px] font-bold text-slate-500">Enterprise SLA</span>
                </div>
              </div>
            </div>

            <div className="mt-6 flex flex-col gap-2">
              <button
                id="modal-checkout-cta"
                onClick={handleTriggerCheckout}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-extrabold shadow transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                Proceed to Secure Checkout
                <ExternalLink className="h-4 w-4" />
              </button>
              
              <button
                id="modal-close-cta"
                onClick={() => setBillingOpen(false)}
                className="w-full py-2.5 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-semibold transition-all cursor-pointer text-center"
              >
                Dismiss Upgrade Plan
              </button>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-center gap-1.5 text-[10px] text-slate-400">
              <ShieldAlert className="h-3.5 w-3.5 text-emerald-600" />
              <span>Checkout security guaranteed by standard Stripe encryption services.</span>
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      <SettingsModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
      />
    </div>
  );
}
