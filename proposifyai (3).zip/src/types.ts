export type ProjectType = 'landscaping' | 'remodeling' | 'contracting' | 'interiordesign' | 'commercial' | 'freelancedesign';

export interface FormInputs {
  clientName: string;
  projectType: ProjectType;
  scopeOfWork: string;
  estimatedMaterials: string;
  budgetRange: string;
  designPreferences: string;
}

export interface ScopeTask {
  task: string;
  description: string;
}

export interface EstimatedCost {
  item: string;
  quantity: number;
  cost: number;
}

export interface TimelinePhase {
  phase: string;
  duration: string;
}

export interface GeneratedProposal {
  executiveSummary: string;
  scopeOfWork: ScopeTask[];
  estimatedCosts: EstimatedCost[];
  timeline: TimelinePhase[];
}

export interface AppSettings {
  apiMode: 'mock' | 'live';
}

export interface UserProfile {
  uid: string;
  email: string | null;
  subscriptionTier: 'free' | 'premium';
  createdAt: string;
  updatedAt: string;
}

export interface SavedProposal {
  id: string;
  clientName: string;
  projectType: ProjectType;
  scopeOfWork: string; // holds original input
  estimatedMaterials: string;
  budgetRange: string;
  designPreferences: string;
  
  executiveSummary: string;
  scopeOfWorkOutput: ScopeTask[]; // holds actual tasks
  estimatedCostsOutput: EstimatedCost[]; // holds actual costs
  timelineOutput: TimelinePhase[]; // holds actual phases
  
  ownerId: string;
  createdAt: string;
  updatedAt: string;
}
