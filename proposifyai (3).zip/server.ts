import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import Stripe from "stripe";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy initialisation of Stripe SDK client. Prevents crashes if key is empty.
let stripeClient: Stripe | null = null;
function getStripe(): Stripe | null {
  const stripeKey = process.env.STRIPE_SECRET_KEY;
  if (!stripeKey) {
    return null; // Graceful sandbox fallback instead of crashing
  }
  if (!stripeClient) {
    stripeClient = new Stripe(stripeKey, {
      apiVersion: "2025-02-02-preview" as any,
    });
  }
  return stripeClient;
}

// Check configuration status of payment processor
app.get("/api/stripe/config", (req, res) => {
  const isConfigured = !!process.env.STRIPE_SECRET_KEY;
  return res.json({
    liveMode: isConfigured,
    publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || "pk_test_sample",
  });
});

// Create stripe billing session or simulate subscription upgrade
app.post("/api/stripe/create-checkout-session", async (req, res) => {
  try {
    const { email, successUrl, cancelUrl, planName = "Professional Team", price = 79 } = req.body;
    const stripe = getStripe();

    const unitAmount = Math.round(price * 100);
    const description = planName === "Contractor Starter"
      ? "15 AI-Optimized proposals/mo, Standard Letterhead, Vector PDF Export."
      : planName === "Enterprise Scale"
      ? "Enterprise-grade custom SLAs, Dedicated database & CRM hookups, White-glove training."
      : "Unlimited AI proposal generations, verified print blueprints & Custom Gemini Key integrations.";

    if (!stripe) {
      console.log(`Stripe is not configured. Falling back to secure simulated checkout for ${planName} ($${price}/mo).`);
      // Return a simulated checkout session page url
      return res.json({
        id: "cs_simulated_" + Math.random().toString(36).substring(2, 12),
        url: `${process.env.APP_URL || "http://localhost:3000"}/checkout-complete?session_id=sim_12345&email=${encodeURIComponent(email || "buyer@test.com")}&plan=${encodeURIComponent(planName)}`,
        simulation: true,
      });
    }

    // Live Stripe Setup
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: `ProposifyAI B2B SaaS ${planName}`,
              description: description,
            },
            unit_amount: unitAmount,
            recurring: { interval: "month" },
          },
          quantity: 1,
        },
      ],
      mode: "subscription",
      customer_email: email,
      success_url: `${successUrl}?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: cancelUrl,
    });

    return res.json({ id: session.id, url: session.url, simulation: false });
  } catch (error: any) {
    console.error("Stripe session creation failure:", error);
    return res.status(500).json({ error: error.message || "Could not generate Stripe Session" });
  }
});

// Live / simulated Webhook receiver
app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), (req, res) => {
  const signature = req.headers["stripe-signature"];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  const stripe = getStripe();

  if (!stripe || !signature || !webhookSecret) {
    // If webhook is executed without real configuration, log and confirm receipt gracefully
    console.log("Stripe webhook received signature without complete live environment variables setup. Assuming sandbox.");
    return res.json({ received: true, simulated: true });
  }

  let event;
  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      signature,
      webhookSecret
    );
  } catch (err: any) {
    console.error(`Webhook Signature verification failed.`, err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle subscription update situations
  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    console.log(`Checkout completed successfully for customer: ${session.customer_email}`);
    // Sync subscription tier in database through callback triggers
  }

  return res.json({ received: true });
});

// API route to generate proposals with server-side Gemini 3.5 API
app.post("/api/generate", async (req, res) => {
  try {
    const {
      clientName,
      projectType,
      scopeOfWork,
      estimatedMaterials,
      budgetRange,
      designPreferences,
    } = req.body;

    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return res.status(400).json({
        error: "Missing API Key. Please configure your key in settings or secrets.",
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });

    const userPrompt = `
      You are an expert sales consultant and estimator in B2B/B2C services for contracting, landscaping, or B2B designs.
      Construct a professional, persuasive, and detailed client project proposal based on these specifics:
      
      Client Details:
      - Client Name: ${clientName || "Valued Client"}
      - Project Type: ${projectType || "General Construction Contract"}
      - Scope of Work Summary: ${scopeOfWork || "General upgrades"}
      - Key Materials Requested: ${estimatedMaterials || "Premium quality contractor-approved matching materials"}
      - Budget Range: ${budgetRange || "Standard service tier"}
      - Design style & preferences: ${designPreferences || "Modern, clean, sustainable, and functional style"}

      Please generate high-quality realistic names for actual tasks, detail descriptions of execution, materials cost breakdowns, and distinct project phases.
    `;

    // Define responseSchema in strict alignment with requirement
    const responseSchema = {
      type: Type.OBJECT,
      properties: {
        executiveSummary: {
          type: Type.STRING,
          description: "An elegant, comprehensive, and client-focused 2-3 paragraph executive summary outlining the value, custom care, aesthetic goals, and project objectives.",
        },
        scopeOfWork: {
          type: Type.ARRAY,
          description: "A chronological list of specific deliverables and detailed construction tasks or design operations required to execute the job.",
          items: {
            type: Type.OBJECT,
            properties: {
              task: { type: Type.STRING, description: "Name of the task/phase, e.g. 'Site Preparation & Excavation'" },
              description: { type: Type.STRING, description: "A detailed 1-2 sentence description specifying what the work entails and the standards of quality applied." },
            },
            required: ["task", "description"],
          },
        },
        estimatedCosts: {
          type: Type.ARRAY,
          description: "Estimated itemized project costs detailing core materials, professional labor tiers, permitting, or design fees.",
          items: {
            type: Type.OBJECT,
            properties: {
              item: { type: Type.STRING, description: "Line item description, e.g. 'Class A Concrete Pouring', 'Custom Birch Cabinetry', 'Design Consulting'" },
              quantity: { type: Type.NUMBER, description: "Unit/hours count." },
              cost: { type: Type.NUMBER, description: "Unit/hourly cost in USD." },
            },
            required: ["item", "quantity", "cost"],
          },
        },
        timeline: {
          type: Type.ARRAY,
          description: "Clear project phase durations showing structure and predictability.",
          items: {
            type: Type.OBJECT,
            properties: {
              phase: { type: Type.STRING, description: "The phase identifier, e.g., 'Phase 1: Initial Preparation', 'Phase 2: Rough Installation', 'Phase 3: Final Inspect'" },
              duration: { type: Type.STRING, description: "Estimated completion speed, e.g. '2-3 Days', 'Week 2', '1 Day'" },
            },
            required: ["phase", "duration"],
          },
        },
      },
      required: ["executiveSummary", "scopeOfWork", "estimatedCosts", "timeline"],
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction: "You are a senior cost estimator and copywriter. Produce completely accurate and highly polished B2B estimates and design proposal details without markdown wrappers or conversational filler.",
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response text generated from the AI model.");
    }

    const proposalJson = JSON.parse(text.trim());
    return res.json(proposalJson);
  } catch (error: any) {
    console.error("API generation error:", error);
    return res.status(500).json({ error: error.message || "An error occurred during proposal generation." });
  }
});

// Configure Vite or Static Files
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

setupServer();
