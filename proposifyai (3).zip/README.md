# ProposifyAI — B2B SaaS AI Estimator & Proposal Builder

ProposifyAI is a fully functional, high-fidelity B2B SaaS platform engineered for general contractors, landscaping professionals, design studios, and freelance professionals. It automates high-polish project scoping, material estimates, timeline planning, and professional contract letterhead printing through deep server-side AI integrations.

## 🚀 Live Preview URLs
- **Development App Preview:** [Vite Hot Reload Sandbox](https://ais-dev-3avtgb37vouls5imkgfhtp-31149740503.europe-west3.run.app)
- **Shared App Link:** [ProposifyAI Live Link](https://ais-pre-3avtgb37vouls5imkgfhtp-31149740503.europe-west3.run.app)

---

## 🔥 Key Product Features

- **Multi-Industry Intake Form Wizard**
  Surgical three-step intake funnel for collecting client names, industry categories, scope narratives, styling aesthetics, and budget brackets.
- **Dynamic Letterhead Blueprint Printing**
  Generates clean, modular, client-facing contract proposals featuring structured executive summaries, checkbox deliverables, cost lines, and timeline phases. Optimized for standard native printer-friendly exports.
- **Relational Cloud Storage (Firestore)**
  Authenticated users can securely save, manage, and instantly reload prior estimating blueprints directly from a real-time sidebar archive.
- **Mock & Live Dual-Processing Engines**
  Includes a fully customized offline mock generator for rapid product testing, alongside a robust Node.js server route connecting directly to Google Gemini 3.5.
- **Stripe Subscription Billing & Tier Limitations**
  Features Contractor Starter ($29/mo), Professional Team ($79/mo), and Enterprise Scale ($199/mo) plans with an intelligent checkout simulation sandbox as well as live Stripe API capabilities.

---

## 🛠️ Technical Stack & Architecture

- **Frontend:** React 18 with Vite, Tailwind CSS, and `lucide-react` icons. Focuses on Inter UI typography and refined JetBrains Mono accents.
- **Backend:** Node.js Express server running on standard port `3000` with native ESM type translation.
- **Identity & Store:** Cloud Firestore and Google Federated Login (fully isolated via firestore-blueprint rules).
- **Bundler:** Built using `esbuild` to compile high-performance backend units safely into CJS modules inside `/dist`.

---

## 💻 Developer Installation & Setup

1. **Clone the project & Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure Environment Variables:**
   Create a standard `.env` configuration file in the project root:
   ```env
   # Node environment state
   NODE_ENV="development"
   APP_URL="http://localhost:3000"

   # Server-side secrets for AI copywriter
   GEMINI_API_KEY="AI_Studio_API_Key"

   # Stripe Subscriptions Integration
   STRIPE_SECRET_KEY="sk_live_..."
   STRIPE_PUBLISHABLE_KEY="pk_live_..."
   STRIPE_WEBHOOK_SECRET="whsec_..."

   # Optional White-Label Firebase Overrides
   # (If left empty, falls back seamlessly to pre-built Google AI Studio test sandbox)
   VITE_FIREBASE_API_KEY="your-firebase-public-api-key"
   VITE_FIREBASE_AUTH_DOMAIN="your-firebase-id.firebaseapp.com"
   VITE_FIREBASE_PROJECT_ID="your-firebase-id"
   VITE_FIREBASE_STORAGE_BUCKET="your-firebase-id.firebasestorage.app"
   VITE_FIREBASE_MESSAGING_SENDER_ID="your-messaging-id"
   VITE_FIREBASE_APP_ID="your-app-id"
   ```

3. **Start the local server:**
   ```bash
   npm run dev
   ```
   *Your live application will boot directly on http://localhost:3000.*

4. **Production Build Compilation:**
   To bundle static frontend components and server files:
   ```bash
   npm run build
   npm start
   ```

---

## 🛑 GitHub Deployment & "Page Not Found / 404" Troubleshooting

If you uploaded this code to GitHub and enabled **GitHub Pages**, or deployed to a static host (like Vercel/Netlify), and encountered a **"Page Not Found" or 404 Error**, here is exactly why it happens and how to resolve it:

### 🔍 1. Why GitHub Pages fails out of the box
ProposifyAI is a **full-stack application** consisting of:
- A React-based Single Page Application (SPA) frontend.
- A Node.js Express server (`server.ts` compiled into `/dist/server.cjs` running on port `3000`) that handles API requests, secure Google Gemini API keys, and sandbox-safe Stripe subscriptions.

**GitHub Pages is a static-only hosting service.** It does not run Node.js backend processes. As a result:
- It fails to execute the backend routing and API.
- Re-loading pages or navigating deep link URLs (like `/checkout-complete`) directly on static hosts throws a "404 Page Not Found" because there is no server-side fallback to route those endpoints back to `index.html`.

---

### 🚀 2. Solution: Deploy as a Full-Stack Web Service (Recommended)
To make your backend routes, Stripe billing checkout, and AI estimators function perfectly on the web, deploy the repository to a Node.js cloud platform (such as **Render.com** or **Railway.app**) directly from your GitHub repository.

#### Option A: Deploying on Render (Free / Low Cost Tier)
1. Go to [Render.com](https://render.com) and create a free account.
2. Click **New +** and select **Web Service**.
3. Connect your GitHub repository.
4. Set the following build settings:
   - **Language / Runtime:** `Node`
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
5. Click **Advanced -> Add Environment Variables** and define your keys:
   - `NODE_ENV` = `production`
   - `GEMINI_API_KEY` = `your_gemini_api_key`
   - `APP_URL` = `https://your-app-subdomain.onrender.com`
6. Deploy! Render will compile your React app, build the Express bundles, and serve them securely without 404 routing errors.

#### Option B: Deploying on Railway.app
1. Go to [Railway.app](https://railway.app) and open a workspace.
2. Click **New Project** -> **Deploy from GitHub repo**.
3. Connect your repository. Railway automatically detects the custom start parameters in your `package.json` configurations.
4. Click **Variables** on the service canvas and enter your secret keys (e.g., `GEMINI_API_KEY`, etc.).
5. Railway boots your full-stack container on a custom public domain instantly!

---

### ⚙️ 3. Alternative: Running Static-Only on GitHub Pages (Mock Mode Only)
If you **only** want to showcase the beautiful client-side visual design on GitHub Pages without using a live server (using Mock Data exclusively):
1. **Set Up Routing Fallback:**
   GitHub Pages requires a copy of your main page to handle route refreshes. Duplicate the `/dist/index.html` build and rename it to `/dist/404.html` in your deployment branch.
2. **Handle Subfolders:**
   If your GitHub Pages URL is nested (e.g., `https://username.github.io/repo-name/`), you must tell Vite's static bundler to prepend the folder path. Inside `vite.config.ts`, add the `base` property:
   ```typescript
   export default defineConfig({
     base: '/repo-name/', // Overwrite this with your Repository Name
     plugins: [react(), tailwindcss()],
     // ...
   });
   ```
3. Set the App state to **Demo Mode** in the settings panel to ensure it bypasses live server API calls.

---
*For a step-by-step buyer acquisition and transfer checklist, review the `/ACQUIRE_TRANSFER_GUIDE.md` document.*

