# Security and Identity Specification

## 1. Data Invariants
- Users can read and write only their own user document (`/users/{uid}`).
- Proposals belong specifically to an `ownerId`. Users can read, create, update, and delete proposals only if the `ownerId` matches the authenticated `request.auth.uid`.
- Document IDs must conform to normal alphanumeric validation structures.
- Timestamps must be validated using server-side variables where applicable.

## 2. The "Dirty Dozen" Payloads
1. **Unauthenticated User profile write**: Writing to `/users/randomUID` without any authentication.
2. **Identity Spoofing Profile write**: Writing to `/users/anotherUID` while authenticated as `user1`.
3. **Privilege Escalation bypass**: Writing to `/users/myUID` attempting to forcibly inject `"subscriptionTier": "premium"` manually via the client SDK.
4. **Unauthenticated Proposal read**: Querying `/proposals/{id}` without credentials.
5. **Cross-Tenant Proposal read**: Querying `user1`'s private proposal as `user2`.
6. **Proposal Spoof Creation**: Attempting to create a proposal with `ownerId` set to a different user's UID to poison historical records.
7. **Proposal Ghost Field inject**: Attempting to inject random properties (e.g., `"adminApproved": true`) not represented in our strict schema.
8. **Malicious ID poisoning**: Creating fields or document paths using 1MB payloads or special shell characters.
9. **Null Auth Bypass**: Simulating a mock client request with a spoofed authorization context.
10. **State short-circuit lockouts**: Writing terminal outcomes or updates using invalid client stamps instead of the official server time.
11. **Mass read exploitation**: Requesting blanket queries of other people's estimates without a safe UID constraint.
12. **PII exposure leak**: Extracting full registered user email rosters without authorization.

## 3. Recommended Security Logic
All requests are evaluated strictly against authenticated user verified variables.
`request.auth.token.email_verified == true` where needed, and strict `request.auth.uid` validation.
